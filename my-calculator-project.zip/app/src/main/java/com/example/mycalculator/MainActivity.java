package com.example.mycalculator;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.text.DecimalFormat;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextView display;
    private String current = "0";
    private double stored = 0;
    private String operator = "";
    private boolean newNumber = true;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 28, 18, 18);
        root.setBackgroundColor(Color.rgb(18,18,18));

        display = new TextView(this);
        display.setText("0");
        display.setTextColor(Color.WHITE);
        display.setTextSize(44);
        display.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        display.setPadding(8, 8, 8, 16);
        root.addView(display, new LinearLayout.LayoutParams(-1, 0, 1.25f));

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        grid.setRowCount(5);
        String[][] keys = {
            {"AC","⌫","%","÷"},
            {"7","8","9","×"},
            {"4","5","6","−"},
            {"1","2","3","+"},
            {"0",".","=","+"}
        };
        for (int r=0;r<5;r++) for (int c=0;c<4;c++) {
            String key = keys[r][c];
            Button v = new Button(this);
            v.setText(key);
            v.setTextSize(23);
            v.setTextColor(Color.WHITE);
            v.setAllCaps(false);
            v.setOnClickListener(x -> press(key));
            GridLayout.LayoutParams p = new GridLayout.LayoutParams(
                GridLayout.spec(r, 1f), GridLayout.spec(c, 1f));
            p.width = 0; p.height = 0;
            p.setMargins(5,5,5,5);
            grid.addView(v,p);
        }
        root.addView(grid, new LinearLayout.LayoutParams(-1, 0, 2.75f));
        setContentView(root);
    }

    private void press(String k) {
        if (k.equals("AC")) { current="0"; stored=0; operator=""; newNumber=true; }
        else if (k.equals("⌫")) { if (current.length()>1) current=current.substring(0,current.length()-1); else current="0"; }
        else if (k.equals("%")) { current=format(parse(current)/100.0); }
        else if ("÷×−+".contains(k)) { stored=parse(current); operator=k; newNumber=true; }
        else if (k.equals("=")) { calculate(); operator=""; newNumber=true; }
        else if (k.equals(".")) { if (newNumber) {current="0."; newNumber=false;} else if (!current.contains(".")) current+="."; }
        else {
            if (newNumber || current.equals("0")) { current=k; newNumber=false; }
            else current += k;
        }
        display.setText(current);
    }

    private void calculate() {
        double b=parse(current), result=stored;
        switch(operator) {
            case "+": result=stored+b; break;
            case "−": result=stored-b; break;
            case "×": result=stored*b; break;
            case "÷": result=(b==0) ? 0 : stored/b; break;
        }
        current=format(result);
    }
    private double parse(String s) {
        try { return Double.parseDouble(s); } catch(Exception e) { return 0; }
    }
    private String format(double n) {
        if (Double.isNaN(n) || Double.isInfinite(n)) return "Ошибка";
        if (Math.abs(n-Math.rint(n)) < 1e-10) return String.format(Locale.US,"%.0f",n);
        return new DecimalFormat("0.##########").format(n);
    }
}
